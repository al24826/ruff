import six
from six import PY3

if six.PY3:
    print("3")
if PY3:
    print("3")
