import sys
from sys import version

print(sys.version[:1])
print(version[:1])
