import sys
from sys import version

version < "3"
sys.version < "3"
sys.version <= "3"
sys.version > "3"
sys.version >= "3"
