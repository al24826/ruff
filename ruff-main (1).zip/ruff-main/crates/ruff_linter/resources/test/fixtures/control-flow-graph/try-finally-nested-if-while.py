def l():
    while T:
        try:
            while ():
                if 3:
                    break
        finally:
            return

