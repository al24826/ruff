# Docstring followed by whitespace with no newline
# Regression test for https://github.com/astral-sh/ruff/issues/7155

def foobar(foor, bar={}):    
    """
    """                    