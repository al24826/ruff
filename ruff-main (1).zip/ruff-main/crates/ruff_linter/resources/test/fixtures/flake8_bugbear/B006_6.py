# Import followed by whitespace with no newline
# Same as B006_2.py, but import instead of docstring

def foobar(foor, bar={}):    
    import os                    