# Import with no newline
# Same as B006_3.py, but import instead of docstring

def foobar(foor, bar={}):    
    import os