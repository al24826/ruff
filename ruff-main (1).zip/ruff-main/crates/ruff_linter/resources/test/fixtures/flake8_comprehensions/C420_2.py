foo or{x: None for x in bar}


# C420 fix must make sure to insert a leading space if needed,
# See https://github.com/astral-sh/ruff/issues/18599
