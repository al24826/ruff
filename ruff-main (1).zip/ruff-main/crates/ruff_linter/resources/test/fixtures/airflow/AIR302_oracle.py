from __future__ import annotations

from airflow.hooks.oracle_hook import OracleHook

OracleHook()
