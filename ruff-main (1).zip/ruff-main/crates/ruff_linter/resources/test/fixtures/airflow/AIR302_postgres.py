from __future__ import annotations

from airflow.hooks.postgres_hook import PostgresHook
from airflow.operators.postgres_operator import Mapping

PostgresHook()
Mapping()
