from __future__ import annotations

from airflow.hooks.samba_hook import SambaHook

SambaHook()
