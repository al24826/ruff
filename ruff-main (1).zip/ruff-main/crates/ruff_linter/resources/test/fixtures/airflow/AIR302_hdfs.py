from __future__ import annotations

from airflow.hooks.webhdfs_hook import WebHDFSHook
from airflow.sensors.web_hdfs_sensor import WebHdfsSensor

WebHDFSHook()
WebHdfsSensor()
