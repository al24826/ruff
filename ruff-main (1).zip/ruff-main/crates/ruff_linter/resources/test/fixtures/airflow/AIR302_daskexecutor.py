from __future__ import annotations

from airflow.executors.dask_executor import DaskExecutor

DaskExecutor()
