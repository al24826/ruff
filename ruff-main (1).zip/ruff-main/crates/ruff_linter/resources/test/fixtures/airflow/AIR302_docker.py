from __future__ import annotations

from airflow.hooks.docker_hook import DockerHook
from airflow.operators.docker_operator import DockerOperator

DockerHook()
DockerOperator()
