from __future__ import annotations

from airflow.hooks.presto_hook import PrestoHook

PrestoHook()
