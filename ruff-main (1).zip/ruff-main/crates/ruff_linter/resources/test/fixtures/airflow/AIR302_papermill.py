from __future__ import annotations

from airflow.operators.papermill_operator import PapermillOperator

PapermillOperator()
