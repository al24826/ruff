from __future__ import annotations

from airflow.hooks.jdbc_hook import (
    JdbcHook,
    jaydebeapi,
)

JdbcHook()
jaydebeapi()
