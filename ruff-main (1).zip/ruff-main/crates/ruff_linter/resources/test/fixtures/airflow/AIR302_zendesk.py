from __future__ import annotations

from airflow.hooks.zendesk_hook import ZendeskHook

ZendeskHook()
