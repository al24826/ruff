from __future__ import annotations

from airflow.hooks.pig_hook import PigCliHook
from airflow.operators.pig_operator import PigOperator

PigCliHook()
PigOperator()
