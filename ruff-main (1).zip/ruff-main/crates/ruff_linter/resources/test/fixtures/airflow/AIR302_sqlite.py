from __future__ import annotations

from airflow.hooks.sqlite_hook import SqliteHook

SqliteHook()
