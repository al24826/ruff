from __future__ import annotations

from airflow.operators.email_operator import EmailOperator

EmailOperator()

from airflow.operators.email import EmailOperator

EmailOperator()
