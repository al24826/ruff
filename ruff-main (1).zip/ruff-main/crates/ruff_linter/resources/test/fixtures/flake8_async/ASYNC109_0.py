import trio


async def func():
    ...


async def func(timeout):
    ...


async def func(timeout=10):
    ...
