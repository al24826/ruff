import telnetlib  # S401
from telnetlib import Telnet  # S401
