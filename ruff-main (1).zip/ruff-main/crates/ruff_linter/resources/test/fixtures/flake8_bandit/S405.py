import xml.etree.cElementTree  # S405
from xml.etree import cElementTree  # S405
import xml.etree.ElementTree  # S405
from xml.etree import ElementTree  # S405
