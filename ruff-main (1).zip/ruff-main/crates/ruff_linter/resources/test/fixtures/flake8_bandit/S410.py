import lxml  # S410
from lxml import etree  # S410
