try:
    pass
except Exception:
    pass

try:
    pass
except:
    pass

try:
    pass
except ValueError:
    pass
