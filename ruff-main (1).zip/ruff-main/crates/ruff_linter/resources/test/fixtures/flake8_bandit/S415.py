import pyghmi  # S415
from pyghmi import foo  # S415

