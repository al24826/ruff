import dill  # S403
from dill import objects  # S403
import shelve
from shelve import open
import cPickle
from cPickle import load
import pickle
from pickle import load
