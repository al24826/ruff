import paramiko

paramiko.exec_command('something; really; unsafe')
