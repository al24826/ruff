from mako.template import Template
from mako import template
import mako


Template("hello")

mako.template.Template("hern")
template.Template("hern")
